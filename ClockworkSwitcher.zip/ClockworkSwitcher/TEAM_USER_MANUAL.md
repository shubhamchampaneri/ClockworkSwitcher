# ⏱ Clockwork Pro & Jira Task Switcher — Team User Manual

---

## 📌 1. What is this System & Why Was it Created?

In our daily work at **Bliss Web Solution**, switching between Jira tasks requires repeating multiple tedious manual steps several times a day:
1. Opening Jira and finding the ticket you were just working on.
2. Manually stopping the running Clockwork timer.
3. Adding a worklog comment describing what was done.
4. Setting the Clockwork billing category (**Billable** vs **Non-Billable**).
5. Transitioning the ticket status in Jira (e.g., from `In QA` to `Done` or `Closed`).
6. Searching for and opening the next task.
7. Starting a new Clockwork timer on that next task.
8. Transitioning the new task's status (e.g., from `Ready for QC` to `In QA`).

### 🚀 What this Automation Solves:
Instead of spending 3–5 minutes per task switch manually clicking through Jira and Clockwork, the **Clockwork & Jira Task Switcher** automates the entire process in **1 single click**:
- **Zero wasted time:** Switch tasks and timers in under 3 seconds.
- **Accurate time tracking:** Never forget to stop an old timer or start a new one.
- **Strict safety rule:** Modifies **ONLY** the Clockwork worklog popup comment — the main Jira task description is **never modified or overwritten**.
- **Live Jira workflow sync:** Valid status transitions (e.g., `Ready for QC` → `In QA`, `In QA` → `Done`) are fetched dynamically from Jira for your exact ticket.

---

## ⚙️ 2. The 9 Automated Steps in 1 Click

When you select your tasks and click **⚡ Switch Task & Timer**, the system automatically executes:

```mermaid
flowchart TD
    A["1. Pause active Clockwork timer"] --> B["2. Open stopped Jira task"]
    B --> C["3. Save worklog description (Popup only)"]
    C --> D["4. Set Billing Type (Billable / Non-Billable)"]
    D --> E["5. (Optional) Transition stopped task status"]
    E --> F["6. Verify worklog & billing saved in Jira"]
    F --> G["7. Open destination Jira task"]
    G --> H["8. Start Clockwork timer on new task"]
    H --> I["9. (Optional) Transition started task status"]
```

---

## 👥 3. How to Access & Share with Team Members (NAS Server)

Every employee at Bliss Web Solution has an individual home directory on the organization NAS server mapped to their **Employee Code** (e.g., `\\nas\ED\BL0080`, `\\nas\ED\BL0074`, etc.).

### 📁 Where the App is Located on the NAS:
The standalone Windows app is deployed and available directly on the NAS server at:
```
\\nas\ED\BL0080\ClockworkSwitcher_App\ClockworkSwitcher.exe
```

### 📲 How Any Team Member Can Run It:
1. **Option A (Run directly from NAS):**
   - Open Windows File Explorer.
   - Go to: `\\nas\ED\BL0080\ClockworkSwitcher_App`
   - Right-click `ClockworkSwitcher.exe` → **Send to → Desktop (create shortcut)**.
   - Double-click the shortcut to run!

2. **Option B (Copy folder to personal desktop):**
   - Copy the entire folder `ClockworkSwitcher_App` from `\\nas\ED\BL0080` to your PC or your personal NAS folder (`\\nas\ED\<YOUR_EMP_CODE>\Desktop`).
   - Run `ClockworkSwitcher.exe`.

> [!NOTE]
> **No Python required!** The executable is completely standalone and contains all necessary runtimes. It runs on any team member's Windows machine out of the box.

---

## 🔑 4. One-Time Setup for Each Team Member

Because Clockwork timers and Jira worklogs are personal, **each team member connects using their own credentials**.

When an employee opens the app for the first time, the **⚙ Settings** dialog opens automatically (or click **⚙ Settings** in the top-right header anytime):

### Configuration Fields:
1. **Detected Employee Code:** Automatically detected from your Windows login (`BL0080`, `BL0074`, etc.).
2. **Jira Base URL:** `https://blisswebsolution.atlassian.net` (pre-filled by default).
3. **Jira Account Email:** Your corporate email (e.g., `yourname@blisswebsolution.com`).
4. **Jira API Token:**
   - Click the blue link in the app: **`🔗 Create Token Online`** (or go to [https://id.atlassian.com/manage-profile/security/api-tokens](https://id.atlassian.com/manage-profile/security/api-tokens)).
   - Click **Create API token**, label it `ClockworkSwitcher`, copy the generated token, and paste it into the field.
5. **Clockwork Pro API Token:**
   - In Jira, open any ticket → Clockwork Pro timer menu → Copy your personal Clockwork API token.
6. Click **🧪 Test Connection**:
   - The app verifies your login and confirms: `✅ Verified! User: [Your Name] | Clockwork: Connected`.
7. Click **💾 Save Settings**.

> [!IMPORTANT]
> Your credentials are saved **only to your private user directory** (`%APPDATA%\ClockworkSwitcher\.env`). They are completely isolated, safe, and never shared with other team members.

---

## 🖥️ 5. Daily Day-to-Day Usage Guide

### Screen Overview:
The interface is structured into two clean cards:
- **Header:** Displays your logged-in Employee Code, email, and live timer pill (`🟢 Active Timer: PTN-988` or `⚪ No Active Timer Detected`).
- **Card 1: Current Task (Stop & Log):** Contains fields to stop the current task, write what you did, choose billing, and optionally change status.
- **Card 2: Next Task (Start & Switch):** Contains fields to pick the destination task and optionally change status.

---

### Step-by-Step Task Switching Workflow:

#### Step 1: Select or Confirm Task to Stop
- The app automatically detects if a Clockwork timer is currently running and pre-fills it in **1. Task to Stop**.
- If switching manually, type any letter in the box to see instant search suggestions.

#### Step 2: Write Worklog Description
- In **2. Worklog Description**, type what you accomplished (e.g., `Fixed responsive layout issues in checkout popup, tested on Chrome and Safari`).
- *Note: This description is saved strictly in the Clockwork time entry comment. It never alters the Jira ticket description.*

#### Step 3: Choose Billing Type
- Select **Non-Billable** or **Billable**.

#### Step 4: (Optional) Transition Status of the Stopped Task
- **4. Change Status for Stopped Task:**
- The app queries Jira in real time for this ticket's valid transitions.
- *Example:* If you were working on a ticket currently in `In QA`, the dropdown offers valid options such as `Done`, `Closed`, `Bugs Sent`, or `-- No Status Change --`.

#### Step 5: Select Task to Start
- In **5. Task to Start**, type or pick the ticket you are switching to (e.g., `WMT-93`, `OT-3`, etc.).

#### Step 6: (Optional) Transition Status of the Started Task
- **6. Change Status for Started Task:**
- **Smart Auto-Selection:** If the destination ticket is currently in **`Ready for QC`**, the app **automatically pre-selects `In QA`** for you!
- You can leave it as `In QA` or change it to `-- No Status Change --` anytime.

#### Step 7: Click ⚡ Switch Task & Timer
- Click the large blue button.
- A progress bar activates while the workflow runs.
- A success popup confirms that the timer was switched, worklog was saved, and ticket statuses were updated in Jira.

---

## ❓ Frequently Asked Questions (FAQ)

### Q1: Does this tool overwrite the Jira ticket's main description?
**No, absolutely not.** The tool is strictly programmed to update only the Clockwork worklog popup comment. The main Jira ticket description is 100% untouched.

### Q2: Can two team members use the tool at the same time?
**Yes.** Each team member runs their own instance mapped to their own Employee Code and personal Jira/Clockwork tokens. No timers or worklogs will ever conflict.

### Q3: What if I don't want to change the Jira status of a ticket?
Both status dropdowns default to **`-- No Status Change --`**. If you don't select a new status, the ticket status remains exactly as it was.

### Q4: How do I refresh my assigned tasks?
Click the **`🔄 Refresh My Tasks`** button in the header. The app queries Jira for all tasks where you are the **Assignee** or **Owner** (including internal `OT` tasks) and refreshes the suggestions.

---
*Created for Bliss Web Solution Team • 2026*
